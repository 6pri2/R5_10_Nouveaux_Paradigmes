﻿/* Eric Porcq p21_1.js 01/03/2016 */
db = connect("maBDDTP2");
console.log(db);
console.log("ça marche maintenant ?");