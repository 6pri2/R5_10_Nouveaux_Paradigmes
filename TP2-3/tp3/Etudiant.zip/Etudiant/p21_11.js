/* Eric Porcq p21_11.js 05/03/2016 */

var mod1 = require("http");
console.log(mod1);