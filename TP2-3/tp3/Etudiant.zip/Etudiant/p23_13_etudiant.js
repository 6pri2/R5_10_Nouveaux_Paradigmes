﻿/* Eric Porcq p23_13_etudiant.js 07/03/2018 */
var net = require("net");
i=1;
	
server = net.createServer();
server.on ("connection",function(socket)
{
	console.log("un client s'est connecté "+i);
	//console.log(socket);
	s = i+"";
	socket.write(s);
	i++;
	server.getConnections( function(err,count)
	{
		console.log(count);
		var val = server.address();
		// compléter
	});
});
server.on ("listening",function()
{
	console.log("le serveur est en écoute");
});
server.listen(3000);

// telnet localhost 3000