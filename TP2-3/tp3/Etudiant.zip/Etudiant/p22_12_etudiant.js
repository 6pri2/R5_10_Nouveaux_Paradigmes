/* Eric Porcq p22_12_etudiant.js 07/03/2018 */
var express = require('express');
var http = require("http");

var url = require('url');
var querystring = require("querystring");
var util = require("util");

var app = express();

app.get('/', function(req, res) {

	res.setHeader('Content-Type', 'text/html; charset="utf-8"');
	res.end("Vous êtes à l'accueil");
});

app.get('/add', function(req, res) {
	// compléter
});

app.get('/fin', function(req, res) {
	// compléter

});

app.on('close', function() {
	console.log('Bye bye !');
}) 

function add(a,b)
{
	var va =parseInt(a);
	var vb =parseInt(b);
	return va+vb;
}

console.log("Serveur en écoute sur le port 3000");
var server = http.createServer(app);
server.listen('3000');
