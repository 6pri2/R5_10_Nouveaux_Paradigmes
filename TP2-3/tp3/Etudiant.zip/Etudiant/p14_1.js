﻿mongoose = require("mongoose");

console.log (mongoose.version);
