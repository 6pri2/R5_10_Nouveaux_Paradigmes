﻿/* Eric Porcq p23_14.js 07/03/2018 */
var net = require("net");
client = net.connect(3000, function()
{

});

